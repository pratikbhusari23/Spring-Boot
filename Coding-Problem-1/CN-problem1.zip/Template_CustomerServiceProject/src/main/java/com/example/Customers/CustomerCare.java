
package com.example.Customers;

public interface CustomerCare {
	
	public String getDepartment();

	public String getService();
	
	public void setCustomerName(String name);
	
	public void setProblem(String problem); 
	
	public void getProblem(); 

	public double getRefId();

	public String getCustomerName();

}
