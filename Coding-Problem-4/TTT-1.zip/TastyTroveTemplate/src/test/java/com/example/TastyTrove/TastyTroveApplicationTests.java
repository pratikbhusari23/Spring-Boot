package com.example.TastyTrove;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TastyTroveApplicationTests {

	@Test
	void contextLoads() {
	}

}
