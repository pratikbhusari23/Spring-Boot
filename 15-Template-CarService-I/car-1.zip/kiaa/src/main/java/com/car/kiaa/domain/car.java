package com.car.kiaa.domain;

public interface car {
    
    public void setDetails(String registrationNumber , String name , String details , String work);
    public Integer getCarId();
}