
package com.example.TastyTrove;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.text.Annotation;
import java.util.Scanner;

@SpringBootApplication
public class TastyTroveApplication {

    public static void main(String[] args) {
        
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext("com.example.TastyTrove");
         

        System.out.println("Welcome to Tasty Trove Application");
        System.out.println("Enter your name? : ");
        Scanner sc = new Scanner(System.in);
        String userName = sc.nextLine();

        // Select Recipe
        System.out.println("Select Recipe: \n 1. North Indian \n 2. South Indian \n 3. Chinese");
        int recipe = sc.nextInt();
        if (recipe < 1 || recipe > 3) {
            System.out.println("Invalid Recipe selection.");
            return;
        }

        // Select Ingredient
        System.out.println("Select Ingredient: \n 1. Lentils \n 2. Rice \n 3. Wheat");
        int ingredient = sc.nextInt();
        if (ingredient < 1 || ingredient > 3) {
            System.out.println("Invalid Ingredient selection.");
            return;
        }

        String beanName = getBeanName(recipe, ingredient);
        if (beanName == null) {
            System.out.println("Invalid Recipe and Ingredient combination.");
            return;
        }

        Recipe recipeBean = context.getBean(beanName,Recipe.class);
        recipeBean.setUserName(userName);
        recipeBean.getDetails();

    }

	private static String getBeanName(int recipe, int ingredient) {
		String[] recipeNames = {"northIndian", "southIndian", "chinese"};
		String[] ingredientNames = {"Lentils", "Rice", "Wheat"};
	
		if (recipe < 1 || recipe > 3 || ingredient < 1 || ingredient > 3) {
			return null;  // Invalid input
		}
		return recipeNames[recipe - 1] + ingredientNames[ingredient - 1];
	}
	
}

