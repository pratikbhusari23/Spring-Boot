package com.example.TastyTrove;

public interface Recipe {

    void getDetails();
    void setIngredients(String ingredients);
    void setUserName(String userName);
}





