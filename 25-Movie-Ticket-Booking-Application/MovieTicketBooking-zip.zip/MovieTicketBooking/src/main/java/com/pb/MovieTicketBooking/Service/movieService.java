package com.pb.MovieTicketBooking.Service;

import com.pb.MovieTicketBooking.Model.movie;

import java.util.List;

public interface movieService {
    
    List<movie> getMovies();
    movie getMovieById(long id);
    String addMovie(movie movie);
    String updateMovie(movie movie , long id);
    String deleteMovie(long id);

}