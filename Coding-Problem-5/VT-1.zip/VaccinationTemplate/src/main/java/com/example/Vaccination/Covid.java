package com.example.Vaccination;

import com.example.Vaccination.Vaccine;

public class Covid implements Vaccine {

    public String getType() {
        return "Covid";
    }
}
