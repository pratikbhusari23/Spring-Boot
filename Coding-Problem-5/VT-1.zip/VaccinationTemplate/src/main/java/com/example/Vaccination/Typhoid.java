package com.example.Vaccination;

import com.example.Vaccination.Vaccine;

public class Typhoid implements Vaccine {

    public String getType() {
        return "Typhoid";
    }
}
