package com.example.Vaccination;

import com.example.Vaccination.Vaccine;

public class Polio implements Vaccine {


    public String getType() {
        return "Polio";
    }
}
