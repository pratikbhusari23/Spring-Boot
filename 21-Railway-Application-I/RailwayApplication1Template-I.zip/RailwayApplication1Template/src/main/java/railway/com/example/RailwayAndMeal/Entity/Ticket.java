package railway.com.example.RailwayAndMeal.Entity;

public class Ticket {
	
	public long pnr;
	public String name;
	public long age;
	public String birth;
	//generate required getters and setters


	public long getPnr() {
		return this.pnr;
	}

	public void setPnr(long pnr) {
		this.pnr = pnr;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getAge() {
		return this.age;
	}

	public void setAge(long age) {
		this.age = age;
	}

	public String getBirth() {
		return this.birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	
}
