package com.example.CarServicePart_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarRegisterationPart_1Application {

	public static void main(String[] args) {
		SpringApplication.run(CarRegisterationPart_1Application.class, args);
	}

}
